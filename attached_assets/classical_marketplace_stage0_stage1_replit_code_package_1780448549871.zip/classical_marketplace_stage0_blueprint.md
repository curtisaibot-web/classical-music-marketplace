# Stage 0 Replit Stabilization Blueprint

**Project:** Classical Music Marketplace  
**Purpose:** Stabilize the existing Replit app before adding new product features.  
**Scope:** Fix narrow technical blockers, confirm environment setup, add smoke tests, and document safe build/test commands.  

## Stage 0 Objective

Stage 0 should not redesign the product. It should make the current app reliable enough that future feature work can be built with confidence. The current project already has a strong marketplace foundation, but the prior read-only audit identified one API typecheck error, environment variables required for frontend builds, and no visible automated smoke test suite.

| Priority | Workstream | Outcome |
|---:|---|---|
| 1 | Fix API typecheck error | `pnpm run typecheck` should no longer fail on `storage.ts`. |
| 2 | Confirm Replit environment | Frontend build should know `PORT` and `BASE_PATH`; backend should know required secrets. |
| 3 | Add smoke tests | Replit can verify the current app before and after new feature work. |
| 4 | Confirm codegen workflow | API spec, Zod schemas, and React Query client stay synchronized. |
| 5 | Update documentation | `replit.md` explains how to run, seed, typecheck, build, and test. |

## Known Current Technical Findings

| Finding | Location | Impact | Fix Strategy |
|---|---|---|---|
| API typecheck error from `string | string[]` route params | `artifacts/api-server/src/routes/storage.ts`, around line 125 | API typecheck fails even though API build succeeds. | Narrow `teacherId` and `fileId` to strings before calling `SAFE_ID.test()`. |
| Frontend build expects `PORT` | `artifacts/marketplace/vite.config.ts` | Build fails if `PORT` is missing outside Replit workflow. | Ensure Replit workflow/env provides `PORT=5173` or document local usage. |
| Frontend build expects `BASE_PATH` | `artifacts/marketplace/vite.config.ts` | Build fails if `BASE_PATH` is missing outside Replit workflow. | Ensure `BASE_PATH=/` unless Replit deployment needs a nested path. |
| No visible dedicated test suite | Repository-wide | New features can regress quietly. | Add lightweight API and frontend smoke tests before Stage 1. |
| Stripe implemented but not connected | Stripe routes and `replit.md` | Payments cannot be fully tested until Stripe is configured. | Decide whether to connect Stripe now or explicitly defer it. |

## Stage 0 Database Changes

Stage 0 should require **no database schema changes** unless Replit discovers a mismatch between the schema and seed data. The only allowed database action is verifying that the current schema can be pushed and seeded in the Replit PostgreSQL environment.

| Action | Command/Area | Expected Result |
|---|---|---|
| Push current schema | `pnpm --filter @workspace/db run push` | Existing tables are created or updated. |
| Seed demo data | `pnpm --filter @workspace/scripts run seed` | Demo teachers, listings, products, events, and bookings load successfully. |
| Avoid new tables | Stage 0 | No product features are added yet. |

## Stage 0 API Requirements

The API work should stay extremely narrow. Replit should fix the `storage.ts` type issue and add/verify smoke-testable public endpoints.

| API Area | Requirement | Acceptance Criteria |
|---|---|---|
| Health endpoint | Confirm `GET /api/healthz` works. | Returns a success response without auth. |
| Public browse endpoints | Confirm public GET routes return valid JSON. | Teachers, listings, masterclasses, events, and digital products routes do not crash. |
| Auth-gated endpoints | Confirm auth gating remains intact. | Private endpoints still require Clerk-authenticated users. |
| Storage route | Fix param typing safely. | Typecheck passes and invalid paths still return `400`. |

## Stage 0 Frontend Requirements

The frontend work should verify the existing routes render. Replit should not redesign pages in Stage 0.

| Frontend Area | Requirement | Acceptance Criteria |
|---|---|---|
| Home route | Render without crash. | Home page loads with no runtime errors. |
| Browse/teachers | Render public browse pages. | Teacher/listing pages load with demo data or graceful empty states. |
| Store | Render digital product store. | Store pages load with demo data or empty states. |
| Events/masterclasses | Render event and masterclass pages. | Pages load and do not break when data is missing. |
| Auth routes | Preserve sign-in/sign-up/onboarding. | Clerk routes remain functional. |

## Stage 0 Replit Prompt

Copy and paste this into Replit first:

```text
You are working in the Classical Music Marketplace monorepo. Do not add new product features yet. This is Stage 0 stabilization only.

Goals:
1. Fix the API TypeScript error in `artifacts/api-server/src/routes/storage.ts` where `teacherId` and `fileId` from `req.params` are treated as `string | string[]` before calling `SAFE_ID.test()`.
2. Confirm the project typechecks and builds in the Replit environment.
3. Confirm or document required env vars for frontend build, especially `PORT` and `BASE_PATH`.
4. Add a lightweight smoke test setup for current behavior only. Do not redesign the app.
5. Update `replit.md` with exact commands for install, typecheck, build, test, DB push, and seed.

Constraints:
- Do not refactor unrelated code.
- Do not add Stage 1 features yet.
- Do not change database schema unless required to fix an existing mismatch.
- Preserve existing Clerk, Stripe, Drizzle, OpenAPI, and React Query patterns.
- If you touch the OpenAPI spec, regenerate the API client and Zod schemas using the existing documented command.

Acceptance criteria:
- `pnpm run typecheck` passes.
- `pnpm run build` passes or any Replit-required env variables are documented and configured.
- API smoke tests cover `/api/healthz` and at least three public GET endpoints.
- Frontend smoke tests verify major public routes render without crashing.
- `git diff` is limited to the narrow fix, tests, and documentation.
```

## Stage 0 Manual Test Checklist

After Replit completes Stage 0, verify the following manually.

| Test | Expected Result |
|---|---|
| Open home page | Loads without runtime errors. |
| Browse teachers | Teachers appear or empty state is shown. |
| Open teacher profile | Profile loads with bio, instruments, reviews if available. |
| Browse events | Events page loads with filters or empty state. |
| Open event detail | Detail page loads and booking request form does not crash. |
| Browse masterclasses | Masterclass listing page loads. |
| Browse store | Digital product store loads. |
| Sign-in button | Clerk sign-in route opens correctly. |
| API health | `/api/healthz` returns success. |
| Typecheck/build | Both pass in Replit. |

## Stage 0 Stop Conditions

Do not proceed to Stage 1 until the app can be built and tested in Replit. If Stripe is not configured, that is acceptable only if it is explicitly documented as deferred. If typecheck still fails, fix that before adding product features.
