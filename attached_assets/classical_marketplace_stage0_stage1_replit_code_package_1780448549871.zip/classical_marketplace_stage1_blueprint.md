# Stage 1 Replit Marketplace Trust Blueprint

**Project:** Classical Music Marketplace  
**Purpose:** Improve discovery, credibility, first-booking conversion, booking confidence, and organic growth.  
**Build principle:** Stage 1 should make the marketplace easier to trust and easier to book before adding deeper Teacher OS or AI features.

## Stage 1 Objective

Stage 1 turns the current marketplace foundation into a clearer, more trustworthy marketplace experience. The goal is to help students and clients quickly answer five questions: **Who can teach me? Can I trust them? Are they available? What happens if I need to reschedule? Can I try this without committing long-term?**

| Stage 1 Feature | Primary User | Business Outcome |
|---|---|---|
| Platform-wide search | Students, parents, event clients | Higher discovery and lower bounce. |
| Advanced teacher filters | Students, parents | Faster teacher matching and better conversion. |
| Teacher verification workflow | Students, parents, teachers | More trust, better profile quality, premium upsell path. |
| Trial lesson booking | Students, teachers | Lower first-booking friction. |
| Lightweight messaging or inquiry flow | Students, teachers, event clients | Less off-platform coordination. |
| Cancellation/rescheduling policies | Students, teachers | Fewer disputes and clearer expectations. |
| Calendar-ready booking UX | Students, teachers | Better scheduling confidence. |
| SEO landing pages | Platform owner | Organic traffic from instrument and city searches. |
| Teacher profile SEO schema | Platform owner, teachers | Better discoverability and richer search presence. |

## Stage 1 Product Scope

Stage 1 should not attempt the full Teacher OS. It should not add practice logs, lesson notes, subscriptions, AI, mock auditions, or event contracts yet. Those are later stages. This stage focuses on the **marketplace trust layer**.

| In Scope | Out of Scope for Stage 1 |
|---|---|
| Search across teachers/listings/events/masterclasses/store. | AI practice feedback. |
| Teacher search filters and sorting. | Practice logs and lesson notes. |
| Teacher verification fields and badges. | Full admin moderation dashboard. |
| Trial lesson support. | Full subscription billing. |
| Policy fields for cancellation/rescheduling. | Full event contracts/deposits. |
| Simple inquiry/messaging MVP. | Full CRM/lead pipeline. |
| SEO landing pages and metadata. | Organization/school accounts. |

## Recommended Stage 1 Database Changes

Replit should inspect the current Drizzle schema first and reuse existing tables where possible. The safest approach is to add small, purpose-built fields to existing profiles/listings and introduce new tables only where the domain needs its own lifecycle.

| Table | Change | Purpose |
|---|---|---|
| `teacher_profiles` | Add `verificationStatus`, `verificationSubmittedAt`, `verifiedAt`, `credentialSummary`, `institutionAffiliations`, `professionalHighlights`, `acceptsTrialLessons`, `trialLessonPriceInCents`, `trialLessonDurationMinutes`, `cancellationPolicy`, `reschedulingPolicy`, `noticeRequiredHours`, `seoSlug`. | Supports trust badges, trial lessons, policies, and SEO. |
| `student_profiles` | Optionally add `preferredInstruments`, `preferredLessonFormat`, `preferredBudgetMin`, `preferredBudgetMax`. | Enables better search matching later; keep optional. |
| `listings` | Add `isTrialEligible`, `bookingLeadTimeHours`, `availableForSearch`, `seoSlug`. | Makes listings searchable and trial-aware. |
| New `teacher_verification_documents` table | Stores teacher ID, document type, file key/path, status, submitted/reviewed timestamps, reviewer notes. | Supports verification without overloading profile fields. |
| New `inquiries` table | Stores sender, recipient teacher, optional listing/event/product reference, subject, message, status, timestamps. | Provides an MVP messaging/inquiry flow without full real-time chat. |
| Optional `seo_landing_pages` table | Stores instrument, city, country, generated slug, title, description, intro copy, enabled flag. | Enables dynamic SEO pages without hardcoding every page. |

### Suggested Enums

| Enum | Values | Notes |
|---|---|---|
| `verification_status` | `not_submitted`, `pending`, `verified`, `rejected`, `expired` | Start simple. |
| `inquiry_status` | `new`, `responded`, `archived`, `converted` | Can later feed the Stage 2 lead pipeline. |
| `lesson_format` | `online`, `in_person`, `hybrid` | Useful for filters and listings. |

## Recommended Stage 1 API Changes

The API should follow the existing route style. If the repo uses OpenAPI/codegen for client hooks, every new API route should be reflected in `lib/api-spec/openapi.yaml`, followed by code generation.

| API Endpoint | Method | Purpose | Auth |
|---|---:|---|---|
| `/search` | GET | Unified search across teachers, listings, events, masterclasses, and digital products. | Public |
| `/teachers` | GET | Extend filters for instrument, city, country, online, skill level, price range, verification, rating, availability. | Public |
| `/teachers/:userId/verification` | GET | Public verification summary. | Public |
| `/teachers/me/verification` | POST | Teacher submits verification metadata/documents. | Teacher |
| `/teachers/me/policies` | PUT | Teacher updates cancellation/rescheduling/trial policies. | Teacher |
| `/inquiries` | POST | Student/client sends inquiry to teacher. | Optional auth preferred; allow unauth with email only if desired. |
| `/inquiries/mine` | GET | Teacher/student views their inquiries. | Auth |
| `/seo/landing-pages` | GET | Retrieve enabled SEO landing page metadata. | Public |
| `/seo/landing-pages/:slug` | GET | Retrieve one SEO landing page and matching teachers/listings. | Public |

## Recommended Stage 1 Frontend Changes

The frontend should keep the current visual direction and extend existing pages before creating entirely new systems. This lowers risk and keeps the user experience coherent.

| Page/Component | Change | Acceptance Criteria |
|---|---|---|
| Home page | Add global search input with instrument/city/service intent. | Users can search for teachers, lessons, events, masterclasses, and products. |
| Browse page | Add unified results or improve existing browse filters. | Results visibly separate teachers, lessons, events, masterclasses, and products. |
| Teachers index | Add advanced filter sidebar or top filter bar. | Filters update URL query params and results. |
| Teacher profile | Add verification badge, credential summary, trial lesson CTA, policy section, and inquiry button. | A visitor can understand trust level, trial option, and cancellation rules. |
| Teacher profile edit | Add verification, policies, trial lesson settings, and SEO slug fields. | Teacher can manage Stage 1 data. |
| Booking flow | Add trial lesson option when teacher/listing supports it. | Trial booking uses existing booking patterns where possible. |
| Inquiry modal/page | Add simple form for questions before booking. | Inquiry reaches teacher dashboard or inbox area. |
| SEO landing page template | Add `/teachers/:instrument/:city` or `/find/:instrument-teachers/:city` pattern. | Pages render title, intro copy, filtered teachers, and internal links. |
| Metadata hook | Use existing `use-page-meta` if available. | Pages have SEO-friendly title and description. |

## Search and Filtering Logic

Search should be useful even before it is perfect. The first version should use query parameters and server-side filtering, not an overbuilt search engine.

| Filter | Applies To | Behavior |
|---|---|---|
| Keyword | All content | Match title, name, instrument, genre, tags, city, country, description. |
| Instrument | Teachers, listings, events, products | Exact or case-insensitive array/text match. |
| Location | Teachers, listings, events | Match city/country; include online results unless excluded. |
| Online/In-person | Teachers/listings/events | Filter by `isOnline` or lesson format. |
| Price range | Teachers/listings/products | Use cents fields. |
| Skill level | Teachers/listings/products | Match beginner/intermediate/advanced/all. |
| Verified only | Teachers | Show only verified teachers. |
| Rating | Teachers | Minimum average rating. |
| Service type | Listings/events/products/masterclasses | Filter by lesson, event, masterclass, digital product. |

## Trial Lesson Logic

Trial lessons should be simple in Stage 1. A trial lesson can be modeled as a booking with a trial flag or as a special listing. Replit should choose the approach that best fits the current schema, but avoid duplicating too much logic.

| Rule | Recommended Behavior |
|---|---|
| Teacher opt-in | Teachers must explicitly enable trial lessons. |
| Price | Trial price can be free or paid; store in cents. |
| Duration | Default 30 minutes, teacher-configurable. |
| Booking status | Use existing booking status flow. |
| Stripe | If Stripe is connected, paid trials use checkout. If not, create pending booking and mark payment as deferred/manual. |
| Abuse prevention | Limit one trial per student/teacher pair unless teacher allows more. |

## Teacher Verification Logic

Teacher verification should start as a practical trust layer, not a complex compliance system. Stage 1 can support submitted credentials and manual review later.

| Verification Element | Stage 1 Behavior |
|---|---|
| Credential summary | Teacher enters public-facing short summary. |
| Institution affiliations | Teacher lists schools, conservatories, orchestras, festivals, or certifications. |
| Document uploads | Optional; use existing object storage if available. |
| Status | Default `not_submitted`; teacher can submit; status becomes `pending`; visible badge only for `verified`. |
| Admin review | If no admin dashboard exists yet, allow manual DB review for now and document future admin dashboard. |
| Public badge | Teacher profile shows `Verified` only when status is `verified`. |

## Inquiry/Messaging MVP Logic

Do not build full real-time chat in Stage 1. Build an **inquiry system** first. This captures intent and can later become the lead pipeline.

| Inquiry Field | Purpose |
|---|---|
| Sender user ID or contact email | Allows auth or guest inquiry capture. |
| Recipient teacher ID | Routes inquiry to teacher. |
| Optional listing/event/product ID | Gives context. |
| Subject | Helps teacher triage. |
| Message | Captures the question. |
| Status | Tracks new/responded/archived/converted. |

## Stage 1 Replit Prompt

Copy and paste this into Replit **only after Stage 0 passes**:

```text
Implement Stage 1 Marketplace Trust for the Classical Music Marketplace. Build this as a focused marketplace improvement sprint, not a redesign.

Product goals:
1. Add platform-wide search across teachers, listings, events, masterclasses, and digital products.
2. Add advanced teacher filters: instrument, city/country, online/in-person, skill level, price range, rating, verified-only, and service type where relevant.
3. Add teacher verification fields, teacher-facing submission UI, and public verification badges.
4. Add trial lesson support with teacher opt-in, price, duration, and booking integration.
5. Add cancellation/rescheduling policy fields and show them on teacher profiles and relevant booking flows.
6. Add a lightweight inquiry system instead of full real-time chat.
7. Add SEO-friendly instrument/city landing pages and teacher profile metadata/schema where practical.

Technical rules:
- Reuse existing tables and routes where possible.
- Add Drizzle schema changes only where needed.
- Update `lib/api-spec/openapi.yaml` for new/changed endpoints and regenerate API clients/Zod schemas using the existing documented command.
- Preserve current Clerk auth and role middleware patterns.
- Preserve current Stripe scaffolding; if Stripe is not configured, paid trial bookings should degrade gracefully as pending/deferred payment.
- Add or update seed data so Stage 1 can be demonstrated with verified teachers, trial lessons, policies, and SEO pages.
- Add smoke tests or integration tests for new public search/filter routes and core UI routes.
- Keep the UI consistent with the existing React/Tailwind/Radix component system.

Suggested implementation order:
1. Schema additions for verification, policies, trial settings, inquiries, and SEO slugs/pages.
2. API route updates for search, teachers filters, verification, policies, inquiries, and SEO pages.
3. OpenAPI/codegen updates.
4. Frontend pages/components for search, filters, badges, trial CTAs, policies, inquiries, and SEO pages.
5. Seed data updates.
6. Tests, typecheck, build, and `replit.md` documentation updates.

Acceptance criteria:
- A visitor can search by keyword/instrument/city and see grouped marketplace results.
- A visitor can filter teachers by instrument, online/in-person, price, rating, and verification status.
- A teacher can configure trial lesson settings and cancellation/rescheduling policies.
- A teacher profile displays verification status, credential summary, trial lesson CTA, and policies.
- A student can request a trial lesson where available.
- A student/client can submit an inquiry to a teacher.
- SEO landing pages render filtered teachers/listings for at least several seeded instrument/city combinations.
- Typecheck, build, and smoke tests pass.
```

## Stage 1 Acceptance Criteria

| Feature | Must Pass |
|---|---|
| Search | Searching “violin”, “piano”, “New York”, or a seeded teacher name returns relevant results. |
| Filters | Combining instrument + online + price range does not crash and returns filtered results. |
| Verification | Verified teachers show badges; unverified teachers do not. |
| Trial lessons | Trial CTA appears only for teachers who enabled trials. |
| Policies | Cancellation/rescheduling text appears on profile and booking pages. |
| Inquiry | Inquiry form validates input and creates an inquiry record. |
| SEO pages | Instrument/city pages load with metadata and filtered results. |
| Auth | Teacher-only settings are protected by existing role middleware. |
| Regression | Existing home, browse, store, events, masterclasses, auth, dashboard pages still load. |

## Stage 1 Stop Conditions

Do not proceed to Stage 2 Teacher OS until Stage 1 search, teacher filters, verification badges, trial lesson CTAs, policies, inquiries, and SEO pages are working against seed data. Stage 2 depends on these foundations because the lead pipeline, reminders, lesson notes, and analytics should build on real search and booking behavior.
