# Classical Music Marketplace: Replit Prompt Pack for Stage 0 and Stage 1

**Use this file as your operating checklist inside Replit.** The safest path is to run the prompts in order. Do not ask Replit to build all 50 features at once.

## How to Use This Prompt Pack

Each prompt is designed to create a controlled development step. After each prompt, review Replit’s changes, run the acceptance checks, and only then move forward. If a step fails, fix that step before continuing.

| Step | Prompt | Purpose |
|---:|---|---|
| 1 | Stage 0 Stabilization | Fix current typecheck/build/test foundation. |
| 2 | Stage 0 Verification | Confirm the existing app runs cleanly. |
| 3 | Stage 1 Schema/API | Add marketplace trust backend foundations. |
| 4 | Stage 1 Frontend | Add search, filters, verification badges, trials, policies, inquiries, and SEO pages. |
| 5 | Stage 1 QA | Test, seed, document, and verify the sprint. |

## Prompt 1: Stage 0 Stabilization

```text
You are working in the Classical Music Marketplace monorepo. Do not add new product features yet. This is Stage 0 stabilization only.

Goals:
1. Fix the API TypeScript error in `artifacts/api-server/src/routes/storage.ts` where `teacherId` and `fileId` from `req.params` are treated as `string | string[]` before calling `SAFE_ID.test()`.
2. Confirm the project typechecks and builds in the Replit environment.
3. Confirm or document required env vars for frontend build, especially `PORT` and `BASE_PATH`.
4. Add a lightweight smoke test setup for current behavior only. Do not redesign the app.
5. Update `replit.md` with exact commands for install, typecheck, build, test, DB push, and seed.

Constraints:
- Do not refactor unrelated code.
- Do not add Stage 1 features yet.
- Do not change database schema unless required to fix an existing mismatch.
- Preserve existing Clerk, Stripe, Drizzle, OpenAPI, and React Query patterns.
- If you touch the OpenAPI spec, regenerate the API client and Zod schemas using the existing documented command.

Acceptance criteria:
- `pnpm run typecheck` passes.
- `pnpm run build` passes or any Replit-required env variables are documented and configured.
- API smoke tests cover `/api/healthz` and at least three public GET endpoints.
- Frontend smoke tests verify major public routes render without crashing.
- `git diff` is limited to the narrow fix, tests, and documentation.
```

## Prompt 2: Stage 0 Verification Pass

```text
Before adding new features, verify the current app. Run typecheck, build, smoke tests, schema push if applicable, and seed if applicable. Then summarize:

1. Which commands passed.
2. Which commands failed, if any.
3. Whether the app runs in Replit.
4. Whether seed data is visible on teachers, events, masterclasses, and store pages.
5. Whether Stripe is connected or explicitly deferred.
6. Whether `replit.md` contains the correct commands and environment notes.

Do not add product features in this step. If anything fails, fix only the failing stabilization issue.
```

## Prompt 3: Stage 1 Schema and API Foundation

```text
Now implement the backend foundation for Stage 1 Marketplace Trust.

Build these features:
1. Platform-wide search endpoint across teachers, listings, events, masterclasses, and digital products.
2. Advanced teacher filters on the existing teachers endpoint.
3. Teacher verification schema fields and teacher verification document table if needed.
4. Trial lesson settings on teacher profiles or listings.
5. Cancellation/rescheduling policy fields.
6. Lightweight inquiries table and API routes.
7. SEO slug fields and optional SEO landing page table.

Technical rules:
- Reuse existing Drizzle schema patterns and route style.
- Keep schema additions minimal and well named.
- Update `lib/api-spec/openapi.yaml` for new or changed endpoints.
- Regenerate API clients/Zod schemas using the existing documented command.
- Preserve Clerk role middleware and require teacher auth for teacher-owned settings.
- Do not build the frontend UI yet except where needed to keep compilation passing.

Expected API endpoints:
- `GET /api/search`
- Extended `GET /api/teachers` filters
- `GET /api/teachers/:userId/verification`
- `POST /api/teachers/me/verification`
- `PUT /api/teachers/me/policies`
- `POST /api/inquiries`
- `GET /api/inquiries/mine`
- `GET /api/seo/landing-pages`
- `GET /api/seo/landing-pages/:slug`

Acceptance criteria:
- Database schema compiles.
- OpenAPI/codegen output is current.
- Public search endpoint returns grouped results.
- Teacher filters work for seeded demo data.
- Teacher-only routes reject unauthenticated/non-teacher users.
- Typecheck passes after backend changes.
```

## Prompt 4: Stage 1 Frontend Implementation

```text
Implement the Stage 1 Marketplace Trust frontend using the backend foundation already added.

Build these UI improvements:
1. Global search entry point on the home page.
2. Search results page showing grouped results: teachers, lessons/listings, events, masterclasses, and digital products.
3. Advanced teacher filter UI with URL query params.
4. Teacher profile verification badge and credential summary.
5. Teacher profile trial lesson CTA when enabled.
6. Teacher profile cancellation/rescheduling policy section.
7. Teacher profile inquiry button/modal/form.
8. Teacher profile edit settings for trial lessons, policies, verification summary, and SEO slug.
9. SEO landing page template for instrument/city pages.
10. Page metadata updates using the existing metadata hook/pattern.

Technical rules:
- Reuse existing React, Tailwind, Radix, and component patterns.
- Keep the UI consistent with the current design.
- Do not add practice logs, lesson notes, AI, subscriptions, event contracts, or admin dashboards yet.
- Add graceful empty states and loading states.
- Make forms validate required fields and show user-friendly errors.

Acceptance criteria:
- Home search navigates to search results.
- Teacher filters update URL query params and results.
- Verified teachers show badges; unverified teachers do not.
- Trial lesson CTA appears only when enabled.
- Inquiry form creates an inquiry.
- SEO landing pages render seeded examples.
- Existing main routes still render without crashing.
```

## Prompt 5: Stage 1 Seed Data, QA, and Documentation

```text
Complete Stage 1 QA and documentation.

Tasks:
1. Add seed data for at least three verified teachers and two unverified teachers.
2. Add trial lesson settings for at least three teachers.
3. Add cancellation/rescheduling policies for seeded teachers.
4. Add sample inquiries if appropriate.
5. Add SEO landing examples for at least five instrument/city combinations.
6. Add or update tests for search, teacher filters, verification visibility, inquiry creation, and SEO page rendering.
7. Run typecheck, build, smoke tests, and any new tests.
8. Update `replit.md` with Stage 1 features, commands, known limitations, and deferred items.

Final response should include:
- Summary of changed files.
- Commands run and results.
- Screens/pages to manually inspect.
- Any known limitations.
- Recommendation for Stage 2 readiness.
```

## Stage 0 Acceptance Checklist

| Check | Pass/Fail |
|---|---|
| API typecheck error in `storage.ts` is fixed. |  |
| `pnpm run typecheck` passes. |  |
| `pnpm run build` passes or env requirements are documented. |  |
| `/api/healthz` works. |  |
| Public GET smoke tests work. |  |
| Frontend public routes render. |  |
| `replit.md` has updated run/test/build/seed instructions. |  |
| Stripe status is documented as connected or deferred. |  |

## Stage 1 Acceptance Checklist

| Check | Pass/Fail |
|---|---|
| Search returns grouped results across marketplace objects. |  |
| Teacher filters support instrument, city/country, online/in-person, skill level, price range, rating, and verified-only. |  |
| Teacher verification data can be submitted. |  |
| Verified badge appears only for verified teachers. |  |
| Trial lesson CTA appears only for trial-enabled teachers. |  |
| Trial booking starts from teacher profile or listing flow. |  |
| Policies appear on teacher profiles and booking-related pages. |  |
| Inquiry form creates a valid inquiry record. |  |
| Teacher can view or receive inquiries. |  |
| SEO landing pages render for seeded instrument/city combinations. |  |
| Page titles/descriptions are improved for SEO pages and teacher profiles. |  |
| Stage 1 seed data demonstrates all new features. |  |
| Existing pages still work: home, browse, teachers, events, masterclasses, store, auth, dashboards. |  |
| Typecheck, build, and tests pass. |  |

## Manual QA Script

Use this script after Stage 1 is complete.

| User Path | Steps | Expected Result |
|---|---|---|
| Search from home | Search “violin New York.” | Results page shows relevant teachers/listings and does not crash. |
| Filter teachers | Apply instrument, online, price, and verified-only filters. | Results narrow correctly and query params update. |
| Inspect verified profile | Open seeded verified teacher profile. | Badge, credentials, trial CTA, and policies appear. |
| Inspect unverified profile | Open seeded unverified teacher profile. | No verified badge appears. |
| Submit inquiry | Send question to teacher. | Inquiry validates and saves. |
| Trial lesson | Click trial lesson CTA. | Booking flow starts with trial context. |
| SEO landing page | Open a seeded instrument/city SEO page. | Page renders custom title, intro, and filtered teachers. |
| Regression | Visit store, events, masterclasses, and dashboards. | Existing pages still load. |

## Stage 2 Readiness Gate

Only move to Stage 2 Teacher OS when the following are true:

| Gate | Required State |
|---|---|
| Build health | Typecheck/build/tests pass reliably. |
| Search | Users can find teachers and listings with useful filters. |
| Trust | Teacher profiles show verification, policies, reviews, and clear CTAs. |
| Conversion | Trial lessons and inquiries work. |
| SEO | Landing pages exist for early organic growth. |
| Documentation | `replit.md` accurately describes the app and commands. |

If these gates are satisfied, Stage 2 should focus on the Teacher OS: lead pipeline, lesson notes, practice assignments, practice logs, repertoire tracker, waitlist management, availability rules, and analytics.
