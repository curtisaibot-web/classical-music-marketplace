# Classical Music Marketplace — Stage 0 + Stage 1 Code Handoff for Replit

**Use this as the single file to give Replit.** It contains a code-oriented implementation plan with file paths, exact code blocks where practical, and explicit instructions for generated files. Because this project uses OpenAPI/Orval/Drizzle code generation, Replit should apply the source changes first, then regenerate generated API files instead of manually editing generated files.

## How to Give This to Replit

Paste the following instruction first:

```text
Implement the code changes in the attached Stage 0 + Stage 1 Code Handoff exactly in the order shown. Do not attempt all optional future features. This handoff is for Stage 0 stabilization and Stage 1 marketplace trust only. After applying source changes, regenerate generated API client/Zod files from OpenAPI using the existing repo command, then run typecheck/build/tests. If any generated file conflicts, prefer OpenAPI as the source of truth.
```

## Implementation Order

| Step | Area | Purpose |
|---:|---|---|
| 1 | Stage 0 storage route fix | Fix current API typecheck issue. |
| 2 | DB schema additions | Add Stage 1 teacher trust, inquiries, and SEO tables/fields. |
| 3 | API route additions | Add `/search`, inquiry routes, SEO routes, verification/policy routes. |
| 4 | OpenAPI updates | Add/modify contract source of truth, then regenerate clients. |
| 5 | Frontend pages | Add search, SEO landing page, and profile trust UI. |
| 6 | Seed/docs/tests | Demonstrate the new functionality and verify it. |

---

# Stage 0 — Fix Current TypeScript Error

## File: `artifacts/api-server/src/routes/storage.ts`

Find the route around `/storage/objects/images/:teacherId/:fileId`. Replace the current param handling block with this safer version:

```ts
const rawTeacherId = req.params.teacherId;
const rawFileId = req.params.fileId;
const teacherId = Array.isArray(rawTeacherId) ? rawTeacherId[0] : rawTeacherId;
const fileId = Array.isArray(rawFileId) ? rawFileId[0] : rawFileId;

const SAFE_ID = /^[\w-]+$/;
if (!teacherId || !fileId || !SAFE_ID.test(teacherId) || !SAFE_ID.test(fileId)) {
  res.status(400).json({ error: "Invalid object path" });
  return;
}
```

This preserves the current security behavior while narrowing `string | string[]` to `string` before `RegExp.test()`.

---

# Stage 1 — Database Schema Changes

## File: `lib/db/src/schema/teacherProfiles.ts`

Modify the imports and table definition. The final file should include these Stage 1 additions.

```ts
import { pgTable, text, timestamp, integer, serial, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const verificationStatusEnum = pgEnum("verification_status", [
  "not_submitted",
  "pending",
  "verified",
  "rejected",
  "expired",
]);

export const teacherProfilesTable = pgTable("teacher_profiles", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }).unique(),
  bio: text("bio"),
  instruments: text("instruments").array().notNull().default([]),
  genres: text("genres").array().notNull().default([]),
  city: text("city"),
  country: text("country"),
  timezone: text("timezone"),
  hourlyRate: integer("hourly_rate"), // in cents
  currency: text("currency").notNull().default("USD"),
  yearsExperience: integer("years_experience"),
  education: text("education"),
  stripeAccountId: text("stripe_account_id"),
  stripeOnboarded: boolean("stripe_onboarded").notNull().default(false),
  averageRating: integer("average_rating").notNull().default(0), // stored as integer * 100
  reviewCount: integer("review_count").notNull().default(0),
  isVerified: boolean("is_verified").notNull().default(false),
  profileImageUrl: text("profile_image_url"),
  websiteUrl: text("website_url"),
  videoIntroUrl: text("video_intro_url"),

  // Stage 1 Marketplace Trust fields
  verificationStatus: verificationStatusEnum("verification_status").notNull().default("not_submitted"),
  verificationSubmittedAt: timestamp("verification_submitted_at", { withTimezone: true }),
  verifiedAt: timestamp("verified_at", { withTimezone: true }),
  credentialSummary: text("credential_summary"),
  institutionAffiliations: text("institution_affiliations").array().notNull().default([]),
  professionalHighlights: text("professional_highlights"),
  acceptsTrialLessons: boolean("accepts_trial_lessons").notNull().default(false),
  trialLessonPriceInCents: integer("trial_lesson_price_in_cents"),
  trialLessonDurationMinutes: integer("trial_lesson_duration_minutes").notNull().default(30),
  cancellationPolicy: text("cancellation_policy"),
  reschedulingPolicy: text("rescheduling_policy"),
  noticeRequiredHours: integer("notice_required_hours").notNull().default(24),
  seoSlug: text("seo_slug").unique(),

  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertTeacherProfileSchema = createInsertSchema(teacherProfilesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertTeacherProfile = z.infer<typeof insertTeacherProfileSchema>;
export type TeacherProfile = typeof teacherProfilesTable.$inferSelect;
```

## New File: `lib/db/src/schema/teacherVerificationDocuments.ts`

```ts
import { pgTable, text, timestamp, integer, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";
import { verificationStatusEnum } from "./teacherProfiles";

export const teacherVerificationDocumentsTable = pgTable("teacher_verification_documents", {
  id: serial("id").primaryKey(),
  teacherId: text("teacher_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  documentType: text("document_type").notNull(), // degree, certification, orchestra_roster, identity, other
  fileKey: text("file_key"),
  publicNote: text("public_note"),
  status: verificationStatusEnum("status").notNull().default("pending"),
  reviewerNotes: text("reviewer_notes"),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertTeacherVerificationDocumentSchema = createInsertSchema(teacherVerificationDocumentsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertTeacherVerificationDocument = z.infer<typeof insertTeacherVerificationDocumentSchema>;
export type TeacherVerificationDocument = typeof teacherVerificationDocumentsTable.$inferSelect;
```

## New File: `lib/db/src/schema/inquiries.ts`

```ts
import { pgTable, text, timestamp, integer, serial, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";
import { listingsTable } from "./listings";

export const inquiryStatusEnum = pgEnum("inquiry_status", ["new", "responded", "archived", "converted"]);

export const inquiriesTable = pgTable("inquiries", {
  id: serial("id").primaryKey(),
  senderId: text("sender_id").references(() => usersTable.id, { onDelete: "set null" }),
  senderName: text("sender_name"),
  senderEmail: text("sender_email"),
  recipientTeacherId: text("recipient_teacher_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  listingId: integer("listing_id").references(() => listingsTable.id, { onDelete: "set null" }),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  status: inquiryStatusEnum("status").notNull().default("new"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertInquirySchema = createInsertSchema(inquiriesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertInquiry = z.infer<typeof insertInquirySchema>;
export type Inquiry = typeof inquiriesTable.$inferSelect;
```

## New File: `lib/db/src/schema/seoLandingPages.ts`

```ts
import { pgTable, text, timestamp, integer, serial, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const seoLandingPagesTable = pgTable("seo_landing_pages", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  instrument: text("instrument"),
  city: text("city"),
  country: text("country"),
  title: text("title").notNull(),
  description: text("description").notNull(),
  introCopy: text("intro_copy"),
  isEnabled: boolean("is_enabled").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertSeoLandingPageSchema = createInsertSchema(seoLandingPagesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertSeoLandingPage = z.infer<typeof insertSeoLandingPageSchema>;
export type SeoLandingPage = typeof seoLandingPagesTable.$inferSelect;
```

## File: `lib/db/src/schema/index.ts`

Add these exports:

```ts
export * from "./teacherVerificationDocuments";
export * from "./inquiries";
export * from "./seoLandingPages";
```

---

# Stage 1 — API Code

## File: `artifacts/api-server/src/routes/teachers.ts`

### 1. Modify imports

Add `desc` and import the new verification table.

```ts
import { eq, and, gte, lte, sql, count, ilike, inArray, desc } from "drizzle-orm";
import { db, teacherProfilesTable, usersTable, listingsTable, masterclassEventsTable, teacherVerificationDocumentsTable } from "@workspace/db";
```

### 2. Extend `/teachers` filtering

After the existing query param reads, add:

```ts
const country = params.success ? (params.data as any).country : undefined;
const skillLevel = params.success ? (params.data as any).skillLevel : undefined;
const minRating = params.success ? (params.data as any).minRating : undefined;
const verifiedOnly = req.query.verifiedOnly === "true";
const query = typeof req.query.q === "string" ? req.query.q.trim() : "";
```

Add these condition blocks before `const where = ...`:

```ts
if (country) {
  conditions.push(ilike(teacherProfilesTable.country, `%${country}%`));
}

if (verifiedOnly) {
  conditions.push(eq(teacherProfilesTable.verificationStatus, "verified"));
}

if (minRating !== undefined) {
  conditions.push(gte(teacherProfilesTable.averageRating, Number(minRating) * 100));
}

if (query) {
  conditions.push(sql`(
    ${teacherProfilesTable.bio} ILIKE ${`%${query}%`} OR
    ${teacherProfilesTable.city} ILIKE ${`%${query}%`} OR
    ${teacherProfilesTable.country} ILIKE ${`%${query}%`} OR
    ${teacherProfilesTable.credentialSummary} ILIKE ${`%${query}%`} OR
    EXISTS (SELECT 1 FROM UNNEST(${teacherProfilesTable.instruments}) AS instr WHERE instr ILIKE ${`%${query}%`}) OR
    EXISTS (SELECT 1 FROM UNNEST(${teacherProfilesTable.genres}) AS genre WHERE genre ILIKE ${`%${query}%`})
  )`);
}

if (skillLevel) {
  const teacherIdsWithSkill = await db
    .selectDistinct({ teacherId: listingsTable.teacherId })
    .from(listingsTable)
    .where(and(eq(listingsTable.skillLevel, skillLevel), eq(listingsTable.status, "active")));
  const ids = teacherIdsWithSkill.map((r) => r.teacherId);
  if (ids.length === 0) {
    res.json(ListTeachersResponse.parse({ teachers: [], total: 0 }));
    return;
  }
  conditions.push(inArray(teacherProfilesTable.userId, ids));
}
```

### 3. Add teacher verification and policy routes before `/teachers/:userId`

```ts
router.get("/teachers/:userId/verification", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.userId) ? req.params.userId[0] : req.params.userId;

  const [profile] = await db
    .select({
      userId: teacherProfilesTable.userId,
      verificationStatus: teacherProfilesTable.verificationStatus,
      isVerified: teacherProfilesTable.isVerified,
      verifiedAt: teacherProfilesTable.verifiedAt,
      credentialSummary: teacherProfilesTable.credentialSummary,
      institutionAffiliations: teacherProfilesTable.institutionAffiliations,
      professionalHighlights: teacherProfilesTable.professionalHighlights,
    })
    .from(teacherProfilesTable)
    .where(eq(teacherProfilesTable.userId, rawId));

  if (!profile) {
    res.status(404).json({ error: "Teacher not found" });
    return;
  }

  res.json(profile);
});

router.post("/teachers/me/verification", requireAuth, async (req, res): Promise<void> => {
  const auth = getAuth(req);
  const userId = auth.userId!;
  const body = req.body as {
    credentialSummary?: string;
    institutionAffiliations?: string[];
    professionalHighlights?: string;
    documents?: Array<{ documentType: string; fileKey?: string; publicNote?: string }>;
  };

  const [profile] = await db
    .update(teacherProfilesTable)
    .set({
      credentialSummary: body.credentialSummary,
      institutionAffiliations: Array.isArray(body.institutionAffiliations) ? body.institutionAffiliations : [],
      professionalHighlights: body.professionalHighlights,
      verificationStatus: "pending",
      verificationSubmittedAt: new Date(),
      updatedAt: new Date(),
    })
    .where(eq(teacherProfilesTable.userId, userId))
    .returning();

  if (!profile) {
    res.status(404).json({ error: "Teacher profile not found" });
    return;
  }

  if (Array.isArray(body.documents) && body.documents.length > 0) {
    await db.insert(teacherVerificationDocumentsTable).values(
      body.documents.map((doc) => ({
        teacherId: userId,
        documentType: doc.documentType,
        fileKey: doc.fileKey,
        publicNote: doc.publicNote,
        status: "pending" as const,
      }))
    );
  }

  res.json({ ok: true, profile });
});

router.put("/teachers/me/policies", requireAuth, async (req, res): Promise<void> => {
  const auth = getAuth(req);
  const userId = auth.userId!;
  const body = req.body as {
    acceptsTrialLessons?: boolean;
    trialLessonPriceInCents?: number | null;
    trialLessonDurationMinutes?: number;
    cancellationPolicy?: string | null;
    reschedulingPolicy?: string | null;
    noticeRequiredHours?: number;
    seoSlug?: string | null;
  };

  const [profile] = await db
    .update(teacherProfilesTable)
    .set({
      acceptsTrialLessons: Boolean(body.acceptsTrialLessons),
      trialLessonPriceInCents: body.trialLessonPriceInCents ?? null,
      trialLessonDurationMinutes: body.trialLessonDurationMinutes ?? 30,
      cancellationPolicy: body.cancellationPolicy ?? null,
      reschedulingPolicy: body.reschedulingPolicy ?? null,
      noticeRequiredHours: body.noticeRequiredHours ?? 24,
      seoSlug: body.seoSlug ?? null,
      updatedAt: new Date(),
    })
    .where(eq(teacherProfilesTable.userId, userId))
    .returning();

  if (!profile) {
    res.status(404).json({ error: "Teacher profile not found" });
    return;
  }

  res.json(profile);
});
```

## New File: `artifacts/api-server/src/routes/search.ts`

```ts
import { Router, type IRouter } from "express";
import { and, eq, ilike, or, sql } from "drizzle-orm";
import { db, teacherProfilesTable, usersTable, listingsTable, masterclassEventsTable, digitalProductsTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/search", async (req, res): Promise<void> => {
  const q = typeof req.query.q === "string" ? req.query.q.trim() : "";
  const instrument = typeof req.query.instrument === "string" ? req.query.instrument.trim() : "";
  const city = typeof req.query.city === "string" ? req.query.city.trim() : "";
  const limit = Math.min(Number(req.query.limit ?? 8) || 8, 25);

  const teacherConditions = [];
  if (q) {
    teacherConditions.push(sql`(
      ${teacherProfilesTable.bio} ILIKE ${`%${q}%`} OR
      ${teacherProfilesTable.city} ILIKE ${`%${q}%`} OR
      EXISTS (SELECT 1 FROM UNNEST(${teacherProfilesTable.instruments}) AS instr WHERE instr ILIKE ${`%${q}%`}) OR
      EXISTS (SELECT 1 FROM UNNEST(${teacherProfilesTable.genres}) AS genre WHERE genre ILIKE ${`%${q}%`})
    )`);
  }
  if (instrument) {
    teacherConditions.push(sql`EXISTS (SELECT 1 FROM UNNEST(${teacherProfilesTable.instruments}) AS instr WHERE LOWER(instr) = LOWER(${instrument}))`);
  }
  if (city) teacherConditions.push(ilike(teacherProfilesTable.city, `%${city}%`));

  const listingConditions = [eq(listingsTable.status, "active")];
  if (q) {
    listingConditions.push(or(
      ilike(listingsTable.title, `%${q}%`),
      ilike(listingsTable.description, `%${q}%`),
      ilike(listingsTable.instrument, `%${q}%`),
      sql`EXISTS (SELECT 1 FROM UNNEST(${listingsTable.tags}) AS tag WHERE tag ILIKE ${`%${q}%`})`,
    )!);
  }
  if (instrument) listingConditions.push(ilike(listingsTable.instrument, `%${instrument}%`));
  if (city) listingConditions.push(ilike(listingsTable.city, `%${city}%`));

  const [teacherRows, listingRows, masterclassRows, productRows] = await Promise.all([
    db.select().from(teacherProfilesTable).leftJoin(usersTable, eq(teacherProfilesTable.userId, usersTable.id)).where(teacherConditions.length ? and(...teacherConditions) : undefined).limit(limit),
    db.select().from(listingsTable).where(and(...listingConditions)).limit(limit),
    db.select().from(masterclassEventsTable).where(and(
      eq(masterclassEventsTable.isCancelled, false),
      q ? or(ilike(masterclassEventsTable.title, `%${q}%`), ilike(masterclassEventsTable.description, `%${q}%`), ilike(masterclassEventsTable.instrument, `%${q}%`))! : sql`true`
    )).limit(limit),
    db.select().from(digitalProductsTable).where(and(
      eq(digitalProductsTable.isPublished, true),
      q ? or(ilike(digitalProductsTable.title, `%${q}%`), ilike(digitalProductsTable.description, `%${q}%`), ilike(digitalProductsTable.instrument, `%${q}%`), ilike(digitalProductsTable.category, `%${q}%`))! : sql`true`
    )).limit(limit),
  ]);

  res.json({
    query: q,
    teachers: teacherRows.map((r) => ({ ...r.teacher_profiles, user: r.users })),
    listings: listingRows,
    masterclasses: masterclassRows,
    digitalProducts: productRows,
  });
});

export default router;
```

## New File: `artifacts/api-server/src/routes/inquiries.ts`

```ts
import { Router, type IRouter } from "express";
import { getAuth } from "@clerk/express";
import { and, desc, eq, or } from "drizzle-orm";
import { db, inquiriesTable, teacherProfilesTable } from "@workspace/db";
import { requireAuth } from "../middlewares/requireAuth";

const router: IRouter = Router();

router.post("/inquiries", async (req, res): Promise<void> => {
  const auth = getAuth(req);
  const userId = auth.userId ?? null;
  const body = req.body as {
    recipientTeacherId?: string;
    listingId?: number;
    senderName?: string;
    senderEmail?: string;
    subject?: string;
    message?: string;
  };

  if (!body.recipientTeacherId || !body.subject || !body.message) {
    res.status(400).json({ error: "recipientTeacherId, subject, and message are required" });
    return;
  }

  if (!userId && !body.senderEmail) {
    res.status(400).json({ error: "Guest inquiries require senderEmail" });
    return;
  }

  const [teacher] = await db
    .select({ userId: teacherProfilesTable.userId })
    .from(teacherProfilesTable)
    .where(eq(teacherProfilesTable.userId, body.recipientTeacherId));

  if (!teacher) {
    res.status(404).json({ error: "Teacher not found" });
    return;
  }

  const [inquiry] = await db.insert(inquiriesTable).values({
    senderId: userId,
    senderName: body.senderName,
    senderEmail: body.senderEmail,
    recipientTeacherId: body.recipientTeacherId,
    listingId: body.listingId,
    subject: body.subject,
    message: body.message,
  }).returning();

  res.status(201).json(inquiry);
});

router.get("/inquiries/mine", requireAuth, async (req, res): Promise<void> => {
  const auth = getAuth(req);
  const userId = auth.userId!;

  const inquiries = await db
    .select()
    .from(inquiriesTable)
    .where(or(eq(inquiriesTable.senderId, userId), eq(inquiriesTable.recipientTeacherId, userId)))
    .orderBy(desc(inquiriesTable.createdAt));

  res.json({ inquiries, total: inquiries.length });
});

export default router;
```

## New File: `artifacts/api-server/src/routes/seo.ts`

```ts
import { Router, type IRouter } from "express";
import { and, eq, ilike, sql } from "drizzle-orm";
import { db, seoLandingPagesTable, teacherProfilesTable, usersTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/seo/landing-pages", async (_req, res): Promise<void> => {
  const pages = await db
    .select()
    .from(seoLandingPagesTable)
    .where(eq(seoLandingPagesTable.isEnabled, true));

  res.json({ pages, total: pages.length });
});

router.get("/seo/landing-pages/:slug", async (req, res): Promise<void> => {
  const slug = Array.isArray(req.params.slug) ? req.params.slug[0] : req.params.slug;

  const [page] = await db
    .select()
    .from(seoLandingPagesTable)
    .where(and(eq(seoLandingPagesTable.slug, slug), eq(seoLandingPagesTable.isEnabled, true)));

  if (!page) {
    res.status(404).json({ error: "SEO landing page not found" });
    return;
  }

  const conditions = [];
  if (page.instrument) {
    conditions.push(sql`EXISTS (SELECT 1 FROM UNNEST(${teacherProfilesTable.instruments}) AS instr WHERE LOWER(instr) = LOWER(${page.instrument}))`);
  }
  if (page.city) {
    conditions.push(ilike(teacherProfilesTable.city, `%${page.city}%`));
  }
  if (page.country) {
    conditions.push(ilike(teacherProfilesTable.country, `%${page.country}%`));
  }

  const rows = await db
    .select()
    .from(teacherProfilesTable)
    .leftJoin(usersTable, eq(teacherProfilesTable.userId, usersTable.id))
    .where(conditions.length ? and(...conditions) : undefined)
    .limit(24);

  res.json({
    page,
    teachers: rows.map((r) => ({ ...r.teacher_profiles, user: r.users })),
  });
});

export default router;
```

## File: `artifacts/api-server/src/routes/index.ts`

Add imports:

```ts
import searchRouter from "./search";
import inquiriesRouter from "./inquiries";
import seoRouter from "./seo";
```

Mount them:

```ts
router.use(searchRouter);
router.use(inquiriesRouter);
router.use(seoRouter);
```

---

# Stage 1 — OpenAPI Contract Updates

## File: `lib/api-spec/openapi.yaml`

Replit should add the new paths and schemas to the OpenAPI file rather than manually editing generated files. At minimum, add:

```yaml
  /search:
    get:
      operationId: searchMarketplace
      tags: [listings]
      summary: Search across marketplace objects
      parameters:
        - name: q
          in: query
          schema: { type: string }
        - name: instrument
          in: query
          schema: { type: string }
        - name: city
          in: query
          schema: { type: string }
        - name: limit
          in: query
          schema: { type: integer, default: 8 }
      responses:
        "200":
          description: Marketplace search results
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/SearchMarketplaceResponse"

  /teachers/{userId}/verification:
    get:
      operationId: getTeacherVerification
      tags: [teachers]
      summary: Get public teacher verification summary
      parameters:
        - name: userId
          in: path
          required: true
          schema: { type: string }
      responses:
        "200":
          description: Teacher verification summary
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/TeacherVerificationSummary"
        "404":
          $ref: "#/components/responses/NotFound"

  /teachers/me/verification:
    post:
      operationId: submitTeacherVerification
      tags: [teachers]
      summary: Submit teacher verification details
      security: [{ clerkAuth: [] }]
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: "#/components/schemas/SubmitTeacherVerificationBody"
      responses:
        "200":
          description: Verification submission accepted
          content:
            application/json:
              schema:
                type: object
                properties:
                  ok: { type: boolean }
                  profile:
                    $ref: "#/components/schemas/TeacherProfile"

  /teachers/me/policies:
    put:
      operationId: updateTeacherPolicies
      tags: [teachers]
      summary: Update teacher trial lesson and policy settings
      security: [{ clerkAuth: [] }]
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: "#/components/schemas/UpdateTeacherPoliciesBody"
      responses:
        "200":
          description: Updated teacher profile
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/TeacherProfile"

  /inquiries:
    post:
      operationId: createInquiry
      tags: [teachers]
      summary: Create a lightweight teacher inquiry
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: "#/components/schemas/CreateInquiryBody"
      responses:
        "201":
          description: Created inquiry
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/Inquiry"

  /inquiries/mine:
    get:
      operationId: listMyInquiries
      tags: [teachers]
      summary: List sent and received inquiries for current user
      security: [{ clerkAuth: [] }]
      responses:
        "200":
          description: My inquiries
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/InquiryListResponse"

  /seo/landing-pages:
    get:
      operationId: listSeoLandingPages
      tags: [teachers]
      summary: List enabled SEO landing pages
      responses:
        "200":
          description: SEO landing pages
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/SeoLandingPageListResponse"

  /seo/landing-pages/{slug}:
    get:
      operationId: getSeoLandingPage
      tags: [teachers]
      summary: Get SEO landing page with matching teachers
      parameters:
        - name: slug
          in: path
          required: true
          schema: { type: string }
      responses:
        "200":
          description: SEO landing page
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/SeoLandingPageResponse"
```

Extend `/teachers` parameters with:

```yaml
        - name: q
          in: query
          schema: { type: string }
        - name: country
          in: query
          schema: { type: string }
        - name: skillLevel
          in: query
          schema:
            type: string
            enum: [beginner, intermediate, advanced, all]
        - name: minRating
          in: query
          schema: { type: number }
        - name: verifiedOnly
          in: query
          schema: { type: boolean }
```

Add these schema fields to `TeacherProfile` and `UpdateTeacherProfileBody` where appropriate:

```yaml
        verificationStatus:
          type: string
          enum: [not_submitted, pending, verified, rejected, expired]
        verificationSubmittedAt:
          type: ["string", "null"]
          format: date-time
        verifiedAt:
          type: ["string", "null"]
          format: date-time
        credentialSummary:
          type: ["string", "null"]
        institutionAffiliations:
          type: array
          items: { type: string }
        professionalHighlights:
          type: ["string", "null"]
        acceptsTrialLessons:
          type: boolean
        trialLessonPriceInCents:
          type: ["integer", "null"]
        trialLessonDurationMinutes:
          type: integer
        cancellationPolicy:
          type: ["string", "null"]
        reschedulingPolicy:
          type: ["string", "null"]
        noticeRequiredHours:
          type: integer
        seoSlug:
          type: ["string", "null"]
```

Add new component schemas:

```yaml
    TeacherVerificationSummary:
      type: object
      properties:
        userId: { type: string }
        verificationStatus:
          type: string
          enum: [not_submitted, pending, verified, rejected, expired]
        isVerified: { type: boolean }
        verifiedAt:
          type: ["string", "null"]
          format: date-time
        credentialSummary:
          type: ["string", "null"]
        institutionAffiliations:
          type: array
          items: { type: string }
        professionalHighlights:
          type: ["string", "null"]
      required: [userId, verificationStatus, isVerified, institutionAffiliations]

    SubmitTeacherVerificationBody:
      type: object
      properties:
        credentialSummary: { type: string }
        institutionAffiliations:
          type: array
          items: { type: string }
        professionalHighlights: { type: string }
        documents:
          type: array
          items:
            type: object
            properties:
              documentType: { type: string }
              fileKey: { type: string }
              publicNote: { type: string }
            required: [documentType]

    UpdateTeacherPoliciesBody:
      type: object
      properties:
        acceptsTrialLessons: { type: boolean }
        trialLessonPriceInCents:
          type: ["integer", "null"]
        trialLessonDurationMinutes: { type: integer }
        cancellationPolicy:
          type: ["string", "null"]
        reschedulingPolicy:
          type: ["string", "null"]
        noticeRequiredHours: { type: integer }
        seoSlug:
          type: ["string", "null"]

    Inquiry:
      type: object
      properties:
        id: { type: integer }
        senderId:
          type: ["string", "null"]
        senderName:
          type: ["string", "null"]
        senderEmail:
          type: ["string", "null"]
        recipientTeacherId: { type: string }
        listingId:
          type: ["integer", "null"]
        subject: { type: string }
        message: { type: string }
        status:
          type: string
          enum: [new, responded, archived, converted]
        createdAt:
          type: string
          format: date-time
      required: [id, recipientTeacherId, subject, message, status, createdAt]

    CreateInquiryBody:
      type: object
      properties:
        recipientTeacherId: { type: string }
        listingId: { type: integer }
        senderName: { type: string }
        senderEmail: { type: string }
        subject: { type: string }
        message: { type: string }
      required: [recipientTeacherId, subject, message]

    InquiryListResponse:
      type: object
      properties:
        inquiries:
          type: array
          items:
            $ref: "#/components/schemas/Inquiry"
        total: { type: integer }
      required: [inquiries, total]

    SeoLandingPage:
      type: object
      properties:
        id: { type: integer }
        slug: { type: string }
        instrument:
          type: ["string", "null"]
        city:
          type: ["string", "null"]
        country:
          type: ["string", "null"]
        title: { type: string }
        description: { type: string }
        introCopy:
          type: ["string", "null"]
        isEnabled: { type: boolean }
      required: [id, slug, title, description, isEnabled]

    SeoLandingPageListResponse:
      type: object
      properties:
        pages:
          type: array
          items:
            $ref: "#/components/schemas/SeoLandingPage"
        total: { type: integer }
      required: [pages, total]

    SeoLandingPageResponse:
      type: object
      properties:
        page:
          $ref: "#/components/schemas/SeoLandingPage"
        teachers:
          type: array
          items:
            $ref: "#/components/schemas/TeacherProfile"
      required: [page, teachers]

    SearchMarketplaceResponse:
      type: object
      properties:
        query: { type: string }
        teachers:
          type: array
          items:
            $ref: "#/components/schemas/TeacherProfile"
        listings:
          type: array
          items:
            $ref: "#/components/schemas/Listing"
        masterclasses:
          type: array
          items:
            $ref: "#/components/schemas/MasterclassEvent"
        digitalProducts:
          type: array
          items:
            $ref: "#/components/schemas/DigitalProduct"
      required: [query, teachers, listings, masterclasses, digitalProducts]
```

Run codegen after editing OpenAPI:

```bash
pnpm --filter @workspace/api-spec run codegen
```

---

# Stage 1 — Frontend Code

Because this project generates React Query hooks from OpenAPI, the following frontend code assumes these generated hooks exist after codegen:

- `useSearchMarketplace`
- `useCreateInquiry`
- `useGetSeoLandingPage`
- `useUpdateTeacherPolicies`
- `useSubmitTeacherVerification`

If Orval generates slightly different hook names, use the generated names.

## New File: `artifacts/marketplace/src/pages/search/index.tsx`

```tsx
import { Link, useLocation } from "wouter";
import { useSearchMarketplace } from "@workspace/api-client-react";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { usePageMeta } from "@/hooks/use-page-meta";
import { Search, MapPin, Music, Store, CalendarDays, GraduationCap } from "lucide-react";
import { useState } from "react";

export default function SearchPage() {
  const [location, setLocation] = useLocation();
  const params = new URLSearchParams(location.split("?")[1] ?? "");
  const initialQ = params.get("q") ?? "";
  const initialInstrument = params.get("instrument") ?? "";
  const initialCity = params.get("city") ?? "";

  const [q, setQ] = useState(initialQ);
  const [instrument, setInstrument] = useState(initialInstrument);
  const [city, setCity] = useState(initialCity);

  usePageMeta({
    title: initialQ ? `Search results for ${initialQ}` : "Search Classical Music Marketplace",
    description: "Search classical music teachers, lessons, events, masterclasses, and digital products.",
  });

  const { data, isLoading } = useSearchMarketplace({ q: initialQ, instrument: initialInstrument, city: initialCity });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const next = new URLSearchParams();
    if (q) next.set("q", q);
    if (instrument) next.set("instrument", instrument);
    if (city) next.set("city", city);
    setLocation(`/search?${next.toString()}`);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <main className="flex-1 container mx-auto px-4 py-10 max-w-6xl">
        <div className="mb-8">
          <h1 className="text-4xl font-serif font-bold mb-3">Search the Marketplace</h1>
          <p className="text-muted-foreground">Find teachers, lessons, masterclasses, events, and digital resources.</p>
        </div>

        <form onSubmit={submit} className="grid gap-3 md:grid-cols-[1fr_220px_220px_auto] mb-10">
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search teachers, instruments, products…" />
          <Input value={instrument} onChange={(e) => setInstrument(e.target.value)} placeholder="Instrument" />
          <Input value={city} onChange={(e) => setCity(e.target.value)} placeholder="City" />
          <Button type="submit" className="gap-2"><Search className="h-4 w-4" /> Search</Button>
        </form>

        {isLoading ? <p className="text-muted-foreground">Searching…</p> : (
          <div className="space-y-10">
            <ResultSection title="Teachers" icon={<GraduationCap className="h-5 w-5" />} count={data?.teachers?.length ?? 0}>
              {data?.teachers?.map((teacher) => (
                <Card key={teacher.userId}>
                  <CardContent className="p-5 flex justify-between gap-4">
                    <div>
                      <Link href={`/teachers/${teacher.userId}`} className="font-semibold text-lg hover:text-primary">
                        {teacher.user?.firstName} {teacher.user?.lastName}
                      </Link>
                      <p className="text-sm text-muted-foreground">{teacher.instruments?.join(" · ")}</p>
                      {teacher.city && <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1"><MapPin className="h-3 w-3" />{teacher.city}</p>}
                    </div>
                    {teacher.verificationStatus === "verified" && <Badge className="bg-emerald-600">Verified</Badge>}
                  </CardContent>
                </Card>
              ))}
            </ResultSection>

            <ResultSection title="Listings" icon={<Music className="h-5 w-5" />} count={data?.listings?.length ?? 0}>
              {data?.listings?.map((listing) => (
                <Card key={listing.id}><CardContent className="p-5"><p className="font-semibold">{listing.title}</p><p className="text-sm text-muted-foreground">{listing.instrument} · ${(listing.priceInCents / 100).toFixed(0)}</p></CardContent></Card>
              ))}
            </ResultSection>

            <ResultSection title="Masterclasses" icon={<CalendarDays className="h-5 w-5" />} count={data?.masterclasses?.length ?? 0}>
              {data?.masterclasses?.map((event) => (
                <Card key={event.id}><CardContent className="p-5"><Link href={`/masterclasses/${event.id}`} className="font-semibold hover:text-primary">{event.title}</Link></CardContent></Card>
              ))}
            </ResultSection>

            <ResultSection title="Digital Products" icon={<Store className="h-5 w-5" />} count={data?.digitalProducts?.length ?? 0}>
              {data?.digitalProducts?.map((product) => (
                <Card key={product.id}><CardContent className="p-5"><Link href={`/store/${product.id}`} className="font-semibold hover:text-primary">{product.title}</Link></CardContent></Card>
              ))}
            </ResultSection>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}

function ResultSection({ title, icon, count, children }: { title: string; icon: React.ReactNode; count: number; children: React.ReactNode }) {
  return (
    <section>
      <div className="flex items-center gap-2 mb-4">
        {icon}<h2 className="text-2xl font-serif font-semibold">{title}</h2><Badge variant="secondary">{count}</Badge>
      </div>
      {count === 0 ? <div className="rounded-xl border border-dashed p-6 text-muted-foreground">No results found.</div> : <div className="grid gap-3">{children}</div>}
    </section>
  );
}
```

## File: `artifacts/marketplace/src/App.tsx`

Add import:

```tsx
import SearchPage from "./pages/search";
```

Add route:

```tsx
<Route path="/search" component={SearchPage} />
```

## File: `artifacts/marketplace/src/pages/home.tsx`

Add a search form in the hero area. Replit should use the existing home page structure, but the core logic is:

```tsx
const [, setLocation] = useLocation();
const [searchQuery, setSearchQuery] = useState("");
const [searchCity, setSearchCity] = useState("");

const handleSearch = (e: React.FormEvent) => {
  e.preventDefault();
  const params = new URLSearchParams();
  if (searchQuery) params.set("q", searchQuery);
  if (searchCity) params.set("city", searchCity);
  setLocation(`/search?${params.toString()}`);
};
```

Then add JSX:

```tsx
<form onSubmit={handleSearch} className="mt-8 grid gap-3 md:grid-cols-[1fr_220px_auto] max-w-3xl">
  <Input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search violin teachers, piano lessons, masterclasses…" />
  <Input value={searchCity} onChange={(e) => setSearchCity(e.target.value)} placeholder="City or online" />
  <Button type="submit">Search</Button>
</form>
```

## Teacher Profile UI Additions

In `artifacts/marketplace/src/pages/teachers/profile.tsx`, add:

- Verified badge text near the existing `CheckCircle` icon.
- Credential summary section after About/Education.
- Policies section in the sidebar.
- Trial lesson CTA in the booking card.
- Inquiry modal using `useCreateInquiry`.

Core snippets:

```tsx
{teacher.verificationStatus === "verified" && (
  <Badge className="bg-emerald-600 text-white gap-1">
    <CheckCircle className="h-3.5 w-3.5" /> Verified Teacher
  </Badge>
)}
```

```tsx
{(teacher.credentialSummary || teacher.professionalHighlights || teacher.institutionAffiliations?.length > 0) && (
  <section>
    <h2 className="text-xl font-serif font-semibold mb-3 text-foreground flex items-center gap-2">
      <Award className="h-5 w-5 text-primary" /> Credentials & Highlights
    </h2>
    {teacher.credentialSummary && <p className="text-muted-foreground leading-relaxed mb-3">{teacher.credentialSummary}</p>}
    {teacher.institutionAffiliations?.length > 0 && (
      <div className="flex flex-wrap gap-2 mb-3">
        {teacher.institutionAffiliations.map((item) => <Badge key={item} variant="secondary">{item}</Badge>)}
      </div>
    )}
    {teacher.professionalHighlights && <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">{teacher.professionalHighlights}</p>}
  </section>
)}
```

```tsx
{teacher.acceptsTrialLessons && (
  <Button variant="outline" className="w-full mb-3" onClick={() => setBookingModalOpen(true)}>
    Request Trial Lesson · {teacher.trialLessonPriceInCents ? `$${(teacher.trialLessonPriceInCents / 100).toFixed(0)}` : "Free"}
  </Button>
)}
```

```tsx
{(teacher.cancellationPolicy || teacher.reschedulingPolicy) && (
  <Card className="border-border">
    <CardContent className="p-5 space-y-3">
      <h3 className="font-serif font-semibold">Booking Policies</h3>
      {teacher.noticeRequiredHours != null && <p className="text-sm text-muted-foreground">Notice required: {teacher.noticeRequiredHours} hours</p>}
      {teacher.cancellationPolicy && <p className="text-sm text-muted-foreground"><strong>Cancellation:</strong> {teacher.cancellationPolicy}</p>}
      {teacher.reschedulingPolicy && <p className="text-sm text-muted-foreground"><strong>Rescheduling:</strong> {teacher.reschedulingPolicy}</p>}
    </CardContent>
  </Card>
)}
```

## Teacher Profile Edit UI Additions

In `artifacts/marketplace/src/pages/teacher/profile-edit.tsx`, add these fields to `formData`:

```tsx
credentialSummary: "",
institutionAffiliations: "",
professionalHighlights: "",
acceptsTrialLessons: false,
trialLessonPriceInCents: 0,
trialLessonDurationMinutes: 30,
cancellationPolicy: "",
reschedulingPolicy: "",
noticeRequiredHours: 24,
seoSlug: "",
```

Populate them in `useEffect` from `profile`, include them in `updateProfile.mutate`, and add UI cards for:

- Verification summary and affiliations.
- Trial lesson settings.
- Cancellation/rescheduling policies.
- SEO slug.

If generated hooks exist for `useUpdateTeacherPolicies` and `useSubmitTeacherVerification`, prefer those. If not, temporarily include the fields in `PUT /teachers/me` after OpenAPI/schema is updated.

## New SEO Landing Page

Create `artifacts/marketplace/src/pages/seo/landing-page.tsx`:

```tsx
import { useParams, Link } from "wouter";
import { useGetSeoLandingPage } from "@workspace/api-client-react";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { usePageMeta } from "@/hooks/use-page-meta";

export default function SeoLandingPage() {
  const { slug } = useParams<{ slug: string }>();
  const { data, isLoading } = useGetSeoLandingPage(slug);

  usePageMeta({
    title: data?.page?.title ?? "Find Classical Music Teachers",
    description: data?.page?.description ?? "Find verified classical music teachers and lessons.",
  });

  if (isLoading) return <div className="min-h-screen bg-background"><Navbar /><main className="container mx-auto px-4 py-12">Loading…</main></div>;
  if (!data) return <div className="min-h-screen bg-background"><Navbar /><main className="container mx-auto px-4 py-12">Page not found.</main></div>;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <main className="flex-1 container mx-auto px-4 py-12 max-w-6xl">
        <h1 className="text-4xl font-serif font-bold mb-3">{data.page.title}</h1>
        <p className="text-muted-foreground max-w-3xl mb-8">{data.page.introCopy || data.page.description}</p>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {data.teachers.map((teacher) => (
            <Card key={teacher.userId}>
              <CardContent className="p-5">
                <Link href={`/teachers/${teacher.userId}`} className="font-semibold hover:text-primary">
                  {teacher.user?.firstName} {teacher.user?.lastName}
                </Link>
                <p className="text-sm text-muted-foreground mt-1">{teacher.instruments.join(" · ")}</p>
                {teacher.verificationStatus === "verified" && <Badge className="mt-3 bg-emerald-600">Verified</Badge>}
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  );
}
```

Add route in `App.tsx`:

```tsx
import SeoLandingPage from "./pages/seo/landing-page";
<Route path="/find/:slug" component={SeoLandingPage} />
```

---

# Seed Data Instructions

## File: `scripts/src/seed.ts`

Replit should update existing seeded teacher profiles with:

```ts
verificationStatus: "verified",
isVerified: true,
verifiedAt: new Date(),
credentialSummary: "Conservatory-trained performer and private instructor with experience preparing students for auditions and recitals.",
institutionAffiliations: ["Juilliard", "Met Orchestra", "Royal Academy of Music"],
professionalHighlights: "Students have placed into youth orchestra programs, conservatory auditions, and regional competitions.",
acceptsTrialLessons: true,
trialLessonPriceInCents: 2500,
trialLessonDurationMinutes: 30,
cancellationPolicy: "Cancel at least 24 hours before the lesson to avoid being charged.",
reschedulingPolicy: "Rescheduling is allowed once per lesson with at least 24 hours notice.",
noticeRequiredHours: 24,
seoSlug: "violin-teacher-new-york",
```

Add SEO landing pages:

```ts
await db.insert(seoLandingPagesTable).values([
  {
    slug: "violin-teachers-new-york",
    instrument: "violin",
    city: "New York",
    country: "United States",
    title: "Find Verified Violin Teachers in New York",
    description: "Browse verified classical violin teachers in New York for private lessons, audition preparation, and trial lessons.",
    introCopy: "Find classical violin teachers in New York who offer private lessons, audition coaching, and trial sessions.",
  },
  {
    slug: "piano-teachers-los-angeles",
    instrument: "piano",
    city: "Los Angeles",
    country: "United States",
    title: "Find Piano Teachers in Los Angeles",
    description: "Browse classical piano teachers in Los Angeles for lessons, recitals, and conservatory preparation.",
    introCopy: "Compare piano teachers in Los Angeles by background, rate, rating, and availability.",
  },
  {
    slug: "cello-teachers-chicago",
    instrument: "cello",
    city: "Chicago",
    country: "United States",
    title: "Find Cello Teachers in Chicago",
    description: "Find classical cello teachers in Chicago offering private lessons and audition preparation.",
    introCopy: "Discover cello teachers for students preparing for recitals, orchestras, and auditions.",
  },
  {
    slug: "voice-teachers-online",
    instrument: "voice",
    title: "Find Online Classical Voice Teachers",
    description: "Browse online classical voice teachers for private lessons, audition prep, and vocal coaching.",
    introCopy: "Connect with classical voice teachers who offer online lessons and performance coaching.",
  },
  {
    slug: "flute-teachers-boston",
    instrument: "flute",
    city: "Boston",
    country: "United States",
    title: "Find Flute Teachers in Boston",
    description: "Browse Boston flute teachers for private lessons, orchestral excerpts, and audition preparation.",
    introCopy: "Find flute instructors in Boston with classical, orchestral, and conservatory preparation experience.",
  },
]).onConflictDoNothing();
```

---

# Commands Replit Should Run

```bash
pnpm install
pnpm --filter @workspace/api-spec run codegen
pnpm --filter @workspace/db run push
pnpm --filter @workspace/scripts run seed
pnpm run typecheck
PORT=5173 BASE_PATH=/ pnpm --filter @workspace/marketplace run build
pnpm --filter @workspace/api-server run build
```

If the root `pnpm run build` fails due environment variables, document the required `PORT` and `BASE_PATH` values in `replit.md` and ensure the Replit workflow sets them.

---

# Acceptance Criteria

| Area | Must Pass |
|---|---|
| Stage 0 | Storage route typecheck error is fixed. |
| Typecheck | `pnpm run typecheck` passes after codegen. |
| Search | `GET /api/search?q=violin` returns grouped results. |
| Teachers | `GET /api/teachers?instrument=violin&verifiedOnly=true` returns verified violin teachers. |
| Verification | Public teacher profile shows verified badge only for verified teachers. |
| Trials | Trial lesson CTA appears only for trial-enabled teachers. |
| Policies | Cancellation and rescheduling policies appear on teacher profiles. |
| Inquiries | `POST /api/inquiries` creates a valid inquiry. |
| SEO | `/find/violin-teachers-new-york` renders a landing page with filtered teachers. |
| Regression | Home, browse, teachers, events, masterclasses, store, auth, dashboards still load. |

---

# Important Constraints for Replit

Do not build Stage 2 yet. Do not add practice logs, lesson notes, AI feedback, subscriptions, full event contracts, admin moderation, or organization accounts. This package is only for **Stage 0 Stabilization** and **Stage 1 Marketplace Trust**.
